/**
 * 
 */
package com.articleservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.articleservice.bean.Article;
import com.articleservice.dao.IArticleDAO;

/**
 * @author M1043827
 *
 */
@Service
public class ServiceImpl implements IService {
	
	@Autowired
	private IArticleDAO articledao;

	@Override
	public List<Article> getAllArticles() {
		List<Article> articles= articledao.getAllArticles();
		return articles;
		
	}

	@Override
	public void createArticle(Article article) {
		articledao.createArticle(article);
		
	}

}
