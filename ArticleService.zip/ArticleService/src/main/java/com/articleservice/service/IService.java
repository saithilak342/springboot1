package com.articleservice.service;

import java.util.List;

import com.articleservice.bean.Article;


public interface IService {

	List<Article> getAllArticles();

	void createArticle(Article article);

}
