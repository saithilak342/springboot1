package com.articleservice.dao;

import java.util.List;

import com.articleservice.bean.Article;

public interface IArticleDAO {

	List<Article> getAllArticles();

	void createArticle(Article article);

}
