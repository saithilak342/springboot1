package com.articleservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.articleservice.bean.Article;

@Transactional
@Repository
public class ArticleDAOImpl implements IArticleDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Article> getAllArticles() {
		String hql = "FROM Article as atcl ORDER BY atcl.articleId DESC";
		return (List<Article>)entityManager.createQuery(hql).getResultList();
		
	}

	@Override
	public void createArticle(Article article) {
		entityManager.persist(article);
		
	}
	
	

}
