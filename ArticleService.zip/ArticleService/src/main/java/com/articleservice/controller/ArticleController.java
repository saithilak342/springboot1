package com.articleservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.articleservice.bean.Article;
import com.articleservice.service.IService;

@RestController
@RequestMapping(value = "/articleservice")
public class ArticleController {

	@Autowired
	private IService articleService;

	@GetMapping(value="/all-articles")
	public ResponseEntity<List<Article>> getAllArticles(){
		List<Article> articles = new ArrayList<Article>();
		try {
			articles=articleService.getAllArticles();
		
		return new ResponseEntity<List<Article>>(articles, HttpStatus.OK);
		}
		catch(Exception e){
			return new ResponseEntity<List<Article>>(articles, HttpStatus.NOT_FOUND);
	}
	}

	@PostMapping(value = "/createArticle")
	public ResponseEntity<String> createArticle(@RequestBody Article article) {
		try {
			System.out.println("in contoller");
			articleService.createArticle(article);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);

		}

	}

}
